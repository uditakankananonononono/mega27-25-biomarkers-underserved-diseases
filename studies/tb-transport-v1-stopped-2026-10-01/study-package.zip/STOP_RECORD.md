# TB transport protocol v1: compatibility stop
October 1, 2026

No external performance result and no biomarker win. The external clinical-label file remains unopened in this study. External expression counts were opened for the frozen compatibility check.

Frozen v1 failed its required gene-universe gate: 1,735/19,201 mapped training genes are not present in the external protein-coding counts. No adaptive intersection or imputation was applied. Training and model locks remain unchanged.

Training GSE42830: 95 samples, exact raw-column duplicate scan passed; 38 healthy excluded, 57 disease samples fitted, 16 TB. Eight disease-state 'Baseline' records were individually verified as Pneumonia in source GSM titles. Four-fold training CV 0.904 is development evidence only, not held-out external validation. Selected panel BHLHE40/AIM2/MEF2D/FCGR1A/TAP1. Nomination BHLHE40 is a training-selected RT-qPCR follow-up candidate, with novelty unverified and no external qualification.

Protocol SHA-256: 1e58a36c3bad3afb450121bbf7a8aceae4d672489f8edf1e26863fc49bff3ab8
Model-lock SHA-256: 20c2a2566bf4b835aa7babc4649040d7884cb2c332bbf63a5c2e7f97ee476bdf
Final-script SHA-256: 2d102803776fcc5fdbb5233f70b162171397aebea84598e13f14e7ddeb1134a1
External-count SHA-256: c8d464d802ead51d032d6ee74e5ad190c014032fb6000460c380700b35cadcde

Scope: rank-Sweeney3 common-scale comparison, not reproduction of original log2TPM/SVA score or comparison to published AUROC 0.906. Training source-design independence does not prove individual person disjointness where keys are absent. Generic covariate-module adjustment is not mechanism proof. Original PLOS correction changes an author name only.

Run sequence: audit_training.py, train.py, final.py. Requires Python numpy, pandas, scipy, scikit-learn, statsmodels, requests. Source inputs are not redistributed. Do not run final.py again under an altered universe and call it v1; the exact stop is the v1 outcome. Any revision must disclose this external assay exposure and preserve v1.

Sources:
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE42830
https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0070630
https://journals.plos.org/plosone/article?id=10.1371/annotation/7d9ec449-aee0-48fe-8111-0c110850c0c1
https://www.ebi.ac.uk/biostudies/api/v1/studies/E-MTAB-8290
https://www.ebi.ac.uk/biostudies/files/E-MTAB-8290/ProcessedDataMatrix_counts.txt
https://pmc.ncbi.nlm.nih.gov/articles/PMC7113842/
