from pathlib import Path
import gzip,io,json,hashlib
import numpy as np,pandas as pd
p=Path(__file__).parent
text=gzip.decompress((p/'sources/GSE42830_series_matrix.txt.gz').read_bytes()).decode()
lines=text.splitlines()
a=lines.index('!series_matrix_table_begin');b=lines.index('!series_matrix_table_end')
x=pd.read_csv(io.StringIO('\n'.join(lines[a+1:b])),sep='\t',index_col=0)
assert x.shape[1]==95 and np.isfinite(x.values).all()
hashes=[hashlib.sha256(x[c].to_numpy().tobytes()).hexdigest() for c in x]
assert len(set(hashes))==95,'Exact duplicate expression columns: STOP'
chars=[l for l in lines[:a] if l.startswith('!Sample_characteristics_ch1\t')]
for l in chars:
 vals=l.split('\t')[1:]
 if all(v.strip('"').startswith('disease state:') for v in vals):
  disease=[v.strip('"').split(':',1)[1].strip() for v in vals]
  break
else:raise ValueError('No explicit disease-state row')
print('TRAINING integrity',x.shape,'95 unique exact column hashes',pd.Series(disease).value_counts().to_dict())
x.to_pickle(p/'sources/training_matrix.pkl')
json.dump(dict(zip(x.columns,disease)),open(p/'sources/training_labels.json','w'))
json.dump({'shape':list(x.shape),'unique_column_hashes':95,'disease_counts':pd.Series(disease).value_counts().to_dict()},open(p/'results/training_integrity.json','w'),indent=2)
