from pathlib import Path
import requests,json,hashlib,io,csv
import numpy as np,pandas as pd
from scipy.stats import rankdata
from scipy.special import expit
from sklearn.metrics import roc_auc_score
P=Path(__file__).parent
lock_bytes=(P/'results/model_lock.json').read_bytes()
assert hashlib.sha256(lock_bytes).hexdigest()=='20c2a2566bf4b835aa7babc4649040d7884cb2c332bbf63a5c2e7f97ee476bdf'
L=json.loads(lock_bytes);U=L['universe'];emap=L['ensembl_map']
def stop(reason,details):
 json.dump({'state':'STOP_EXTERNAL_UNOPENED_LABELS','reason':reason,'details':details},open(P/'results/final_result.json','w'),indent=2)
 print(reason,details);raise SystemExit(2)
u='https://www.ebi.ac.uk/biostudies/files/E-MTAB-8290/ProcessedDataMatrix_counts.txt'
r=requests.get(u,timeout=90);r.raise_for_status();(P/'sources/external_counts.txt').write_bytes(r.content)
x=pd.read_csv(io.BytesIO(r.content),sep='\t',index_col=0);assert x.shape[1]==181 and np.isfinite(x.values).all()
# Only unambiguous annotation mapping, same frozen training universe.
x.index=x.index.astype(str).str.split('.').str[0]
if x.index.duplicated().any():stop('Duplicate gene IDs in external counts',int(x.index.duplicated().sum()))
missing=[g for g in U if emap[g] not in x.index]
if missing:stop('Fixed universe missing external genes',{'count':len(missing),'examples':missing[:12],'external_sha256':hashlib.sha256(r.content).hexdigest()})
raw=x.loc[[emap[g] for g in U]].copy();raw.index=U
Z=rankdata(raw.to_numpy(),axis=0,method='average')/(len(U)+1)
T=pd.read_pickle(P/'sources/training_gene_rank.pkl').loc[U].to_numpy()
# Center ranks for Pearson correlation of tied ranks = Spearman rank correlation.
A=Z-Z.mean(axis=0);B=T-T.mean(axis=0);corr=(B.T@A)/(np.linalg.norm(B,axis=0)[:,None]*np.linalg.norm(A,axis=0)[None,:])
if (corr>=.999999).any():stop('Cross-source near-identical rank profile',{'max_correlation':float(corr.max())})
if pd.DataFrame(Z.T).duplicated().any():stop('External duplicate rank columns',int(pd.DataFrame(Z.T).duplicated().sum()))
print('External integrity PASS, labels still unopened',float(corr.max()))
ix=[U.index(g) for g in L['panel']];pred=expit(np.array(L['coef'])@Z[ix]+L['intercept'])
base=(Z[U.index('GBP5')]+Z[U.index('DUSP3')])/2-Z[U.index('KLF2')]
# First and only external disease-label opening AFTER model lock and integrity.
u2='https://www.ebi.ac.uk/biostudies/files/E-MTAB-8290/E-MTAB-8290.sdrf.txt'
r2=requests.get(u2,timeout=30);r2.raise_for_status();rows=list(csv.DictReader(io.StringIO(r2.text),delimiter='\t'))
labels={}
for row in rows:
 key=row['Characteristics[individual]'];d=row['Characteristics[disease]']
 if key in labels:assert labels[key]==d
 labels[key]=d
classes=set(labels.values());print('External disease strings',classes)
# Source field must specify tuberculosis or explicit non-TB label; never substring invert unknowns.
allowed_tb={'tuberculosis','pulmonary tuberculosis','Tuberculosis'}
allowed_other={'non-tuberculosis','non tuberculosis','non-TB','No TB','no tuberculosis','other disease','not tuberculosis'}
if not classes<=allowed_tb|allowed_other:
 json.dump({'state':'STOP_LABEL_MAPPING','observed_classes':sorted(classes)},open(P/'results/final_result.json','w'),indent=2);raise SystemExit(3)
y=np.array([int(labels[c] in allowed_tb) for c in x.columns]);assert len(y)==181
auc=roc_auc_score(y,pred);bauc=roc_auc_score(y,base);rng=np.random.default_rng(20261002);deltas=[]
for _ in range(10000):
 ids=np.concatenate([rng.choice(np.flatnonzero(y==v),sum(y==v),replace=True) for v in [0,1]])
 deltas.append(roc_auc_score(y[ids],pred[ids])-roc_auc_score(y[ids],base[ids]))
ci=np.quantile(deltas,[.025,.975]);out={'state':'COMPLETE','n':len(y),'cases':int(y.sum()),'challenger_auc':float(auc),'rank_sweeney3_auc':float(bauc),'delta_auc':float(auc-bauc),'paired_delta_ci95':ci.tolist(),'win':bool(ci[0]>0),'max_cross_source_rank_correlation':float(corr.max()),'counts_sha256':hashlib.sha256(r.content).hexdigest(),'label_source_sha256':hashlib.sha256(r2.content).hexdigest(),'panel':L['panel'],'nomination':L['lab_nomination']}
for name,s,thr in [('challenger',pred,L['challenger_threshold']),('baseline',base,L['baseline_threshold'])]:
 out[name+'_locked_sensitivity']=float(((s>=thr)&(y==1)).sum()/sum(y==1));out[name+'_locked_specificity']=float(((s<thr)&(y==0)).sum()/sum(y==0))
json.dump(out,open(P/'results/final_result.json','w'),indent=2);print(json.dumps(out,indent=2))
