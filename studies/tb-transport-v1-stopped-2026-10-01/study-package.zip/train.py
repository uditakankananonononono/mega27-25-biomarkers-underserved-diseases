from pathlib import Path
import json,gzip,io,hashlib,pickle
import numpy as np,pandas as pd
from scipy.stats import rankdata,spearmanr
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score,roc_curve
from sklearn.model_selection import StratifiedKFold
P=Path(__file__).parent
x=pd.read_pickle(P/'sources/training_matrix.pkl')
labels=json.load(open(P/'sources/training_labels.json'))
# Explicit source-title audit: all eight Baseline records are Pneumonia Sample N training set.
valid={'TB':1,'Active Sarcoid':0,'Non-active sarcoidosis':0,'lung cancer':0,'Baseline':0}
columns=[c for c in x if labels[c] in valid];y=np.array([valid[labels[c]] for c in columns])
assert len(y)==57 and y.sum()==16
ann=gzip.decompress((P/'sources/GPL10558.annot.gz').read_bytes()).decode()
lines=ann.splitlines();a=next(i for i,l in enumerate(lines) if l.startswith('ID\t'));b=next((i for i in range(a+1,len(lines)) if lines[i].startswith('!platform_table_end')),len(lines))
gpl=pd.read_csv(io.StringIO('\n'.join(lines[a:b])),sep='\t',dtype=str)
gpl=gpl[gpl['Gene symbol'].str.fullmatch(r'[A-Za-z0-9_.-]+',na=False)].set_index('ID')
h=pd.read_csv(P/'sources/hgnc.txt',sep='\t',dtype=str,usecols=['symbol','ensembl_gene_id']).dropna()
h=h[~h.symbol.duplicated(keep=False)&~h.ensembl_gene_id.duplicated(keep=False)]
ids=x.index.intersection(gpl.index);raw=x.loc[ids].copy();raw['symbol']=gpl.loc[ids,'Gene symbol'];raw=raw.groupby('symbol').median();raw=raw.loc[raw.index.intersection(h.symbol)].sort_index()
universe=list(raw.index);assert all(g in universe for g in ['GBP5','DUSP3','KLF2'])
rank=pd.DataFrame(rankdata(raw.to_numpy(),axis=0,method='average')/(len(raw)+1),index=raw.index,columns=raw.columns)
X=rank[columns].T.to_numpy();genes=np.array(universe)
def select(X,y,seed=20261001):
 rng=np.random.default_rng(seed);freq=np.zeros(X.shape[1]);effects=np.zeros(X.shape[1])
 for k in range(20):
  ii=np.concatenate([rng.choice(np.flatnonzero(y==v),sum(y==v),replace=True) for v in [0,1]])
  rr=rankdata(X[ii],axis=0);n1=sum(y[ii]==1);n0=sum(y[ii]==0)
  auc=(rr[y[ii]==1].sum(axis=0)-n1*(n1+1)/2)/(n0*n1);effect=np.abs(auc-.5);effects+=effect
  order=np.lexsort((genes,-effect));freq[order[:20]]+=1
 order=np.lexsort((genes,-effects,-freq))[:5]
 return order,freq,effects/20
idx,freq,effects=select(X,y)
model=LogisticRegression(C=1,class_weight='balanced',solver='lbfgs',max_iter=1000).fit(X[:,idx],y)
probs=model.predict_proba(X[:,idx])[:,1]
baseline=(rank.loc['GBP5',columns].values+rank.loc['DUSP3',columns].values)/2-rank.loc['KLF2',columns].values
def threshold(y,s):
 f,t,z=roc_curve(y,s);valid=np.isfinite(z);o=np.lexsort((-t[valid],-(t-f)[valid]))[0];return float(z[valid][o])
cv=np.zeros(len(y))
for tr,te in StratifiedKFold(4,shuffle=True,random_state=20261001).split(X,y):
 ix,_,_=select(X[tr],y[tr]);m=LogisticRegression(C=1,class_weight='balanced',max_iter=1000).fit(X[tr][:,ix],y[tr]);cv[te]=m.predict_proba(X[te][:,ix])[:,1]
mechanism=[]
modules=[]
for gl in [['IFIT1','IFIT3','ISG15','MX1','OAS1'],['S100A8','S100A9','FCGR3B','CSF3R']]:
 measured=[g for g in gl if g in universe];assert len(measured)>=2;modules.append(rank.loc[measured,columns].mean().values)
import statsmodels.api as sm
for i in idx:
 design=sm.add_constant(np.column_stack([X[:,i]]+modules));
 try:
  m=sm.GLM(y,design,family=sm.families.Binomial()).fit();adj={'beta':float(m.params[1]),'p_descriptive':float(m.pvalues[1])}
 except Exception as e:adj={'unavailable':str(e)}
 mechanism.append({'gene':str(genes[i]),'ifn_spearman':float(spearmanr(X[:,i],modules[0]).statistic),'myeloid_spearman':float(spearmanr(X[:,i],modules[1]).statistic),'module_adjusted':adj})
lock={'universe':universe,'ensembl_map':dict(zip(h.symbol,h.ensembl_gene_id)),'panel':genes[idx].tolist(),'challenger_threshold':threshold(y,probs),'baseline_threshold':threshold(y,baseline),'coef':model.coef_[0].tolist(),'intercept':float(model.intercept_[0]),'training_n':len(y),'training_cases':int(y.sum()),'training_cv_auc':float(roc_auc_score(y,cv)),'training_baseline_auc':float(roc_auc_score(y,baseline)),'selection':[{'gene':str(genes[i]),'frequency':int(freq[i]),'mean_abs_auc_deviation':float(effects[i])} for i in idx],'mechanism':mechanism,'lab_nomination':next((g for g in genes[idx] if g not in ['GBP5','DUSP3','KLF2']),str(genes[idx[0]]))}
json.dump(lock,open(P/'results/model_lock.json','w'),indent=2)
raw.to_pickle(P/'sources/training_gene_raw.pkl');rank.to_pickle(P/'sources/training_gene_rank.pkl')
print(json.dumps({k:v for k,v in lock.items() if k not in ['universe','ensembl_map']},indent=2));print('universe',len(universe),'model lock sha',hashlib.sha256((P/'results/model_lock.json').read_bytes()).hexdigest())
