import unittest
import numpy as np
from scipy.stats import rankdata
from scipy.special import expit
from sklearn.metrics import roc_auc_score
class Checks(unittest.TestCase):
 def test_rank_monotone_invariance(self):
  x=np.array([[1.,2.],[2.,8.],[4.,3.]])
  np.testing.assert_array_equal(rankdata(x,axis=0),rankdata(np.log1p(x),axis=0))
 def test_tied_ranks(self):
  np.testing.assert_equal(rankdata([1,1,2]),[1.5,1.5,3])
 def test_paired_auc_direction(self):
  y=[0,0,1,1];self.assertLess(roc_auc_score(y,[0,1,0,1])-roc_auc_score(y,[0,0,1,1]),0)
 def test_saved_model_equation(self):
  import json
  from pathlib import Path
  l=json.load(open(Path(__file__).parent/'results/model_lock.json'))
  p=expit(np.array(l['coef'])@np.full(5,.5)+l['intercept'])
  self.assertTrue(0<p<1)
 def test_result_no_win(self):
  import json
  from pathlib import Path
  r=json.load(open(Path(__file__).parent/'results/final_result.json'))
  self.assertFalse(r['win']);self.assertLess(r['paired_delta_ci95'][1],0)
if __name__=='__main__':unittest.main()
